<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;

class AuthenticationController extends Controller
{
    /**
     * Handle an incoming authentication request.
     */
    public function login()
    {
        /**
         * Scopes for the token must be passed as an array by client application
         */
        if (Auth::attempt(['username' => request('username'), 'password' => request('password')])) {
            // successfull authentication
            $user = User::find(Auth::user()->id);

            $scopes = request('scope') ? explode(' ', request('scope')) : ['view-user'];

            $user_token['token'] = $user->createToken('appToken', $scopes)->accessToken;

            return response()->json([
                'success' => true,
                'token' => $user_token,
                'user' => $user,
            ], 200);
        } else {
            // failure to authenticate
            return response()->json([
                'success' => false,
                'message' => 'Failed to authenticate.',
            ], 401);
        }
    }

    /**
     * Destroy an authenticated session
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(Request $request)
    {
        // ...
        if (Auth::user()) {
            $request->user()->token()->revoke();
            Auth::logout();

            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return response()->json([
                'success' => true,
                'message' => 'Logged out successfully',
            ], 200);
        }
    }
}
