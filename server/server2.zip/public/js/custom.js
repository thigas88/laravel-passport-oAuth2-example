
$(document).ready(function () {
    

    /*
     * Autorização para chamadas ajax
     */
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

});
