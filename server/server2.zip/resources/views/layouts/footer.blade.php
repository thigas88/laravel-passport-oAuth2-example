<footer class="br-footer pt-3" id="footer">
    <div class="container-lg">
        <div class="info">
            <div class="text-down-01 text-medium pb-3">Ao utilizar este site e seus serviços você concoda com os&nbsp;<strong><a
                            href="{{ env('APP_PRIVACY_URL', '')  }}"
                            target="_blank">Termos de Uso e Privacidade</a></strong></div>
        </div>
    </div>
</footer>
{{--    <div class="br-cookiebar default d-none" tabindex="-1"></div>--}}