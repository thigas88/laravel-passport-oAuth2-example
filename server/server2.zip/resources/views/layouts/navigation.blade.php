<a class="menu-item divider" href="{{ route('home') }}">
    <span class="icon"><i class="fa fa-th-large"></i></span>
    <span class="content">Painel</span>
</a>
