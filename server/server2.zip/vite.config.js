import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    build:{
        commonjsOptions: {
            sourceMap: false
        }
    },
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                '@govbr-ds/core/dist/core.min.css',
                'resources/css/custom.css', 
                '@govbr-ds/core/dist/core.min.js',
                '@govbr-ds/core/dist/core-init.js',
                'resources/js/app.js'
            ],
            refresh: true,
        }),
    ],
    server: {
        hmr: {
            host: 'host.docker.internal',
        },
    },

});
